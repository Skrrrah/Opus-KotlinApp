package maurya.devansh.bookidentification.screens.bookslist

/**
 * Created by Devansh on 27/4/19.
 */
interface OnBookItemSelectedListener {

    fun onBookItemSelected(bookVolume: String)
}